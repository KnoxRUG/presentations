# Source functions
source("~/my_functions_2014-10-01.R")

# Read command-line arguments
my_arguments = commandArgs(trailingOnly = T)
# my_arguments = c("GroceryStores.txt", "Beer.txt", "OverlapTable.png")

# Main function
my_function = function() {

  # If 3 arguments weren't given, return error message
  if(length(my_arguments) != 3) {
    return(cat("Usage: Rscript my_script.R <input file 1> <input file 2> <output file.png>\n"))
  }
  
  # Store command-line arguments as variables
  file_1 = my_arguments[1]
  file_2 = my_arguments[2]
  output_file = my_arguments[3]
  
  
  # If either input file doesn't exist, terminate and return message
  if (!file.exists(file_1)) {
    return(cat("Can't open", file_1, "\n"))
  } 
  
  if (!file.exists(file_2)) {
    return(cat("Can't open", file_2, "\n"))
  } 
  
  # Use custom function to read files into lists.  Names of the list are categories (i.e., brands of beer),
  # and each element of the list is a character vector containing customer IDs  
  store_data = read_list(file_1)
  beer_data = read_list(file_2)
  
  # Use custom function to find the overlap between each character vector from both lists
  # Returns a matrix containg the size of overlap in each cell and an additional row and column for total
  my_overlap = find_overlap(store_data, beer_data)
  
  # Use custom function to find the odds ratios and p-values for each overlap, based on the Fisher exact test
  # Returns a list with two elements, both matrices, one named "odds" and one named "p"
  fish_results = fish.table(my_overlap, test = "right")
  
  # Format odds ratio data so that it is rounded to 1 significant digit
  odds_data = fish_results$odds
  odds_data_formatted = as.matrix(round(odds_data, 1))
  
  # Format p-value data so that it is rounded to 2 significant digits
  p_data = fish_results$p
  p_data_formatted = as.matrix(signif(p_data, 2))
  
  # Format original overlap numbers.  All that's needed is to get rid of the total 
  # row and column and makes sure it's in matrix format (required for heatmap function)
  raw_data = my_overlap[-nrow(my_overlap),-ncol(my_overlap)]
  raw_data_formatted = as.matrix(raw_data)
  
  # Create a matrix of character strings of the same dimensions as our data
  # Use "paste" to paste together the original value, plus a newline character,
  # so that when added as labels on plot, there is extra room to print more text
  table_data1 = matrix(paste(raw_data_formatted, "\n", sep = ""),
                       nrow = nrow(raw_data_formatted), ncol = ncol(raw_data_formatted), 
                       dimnames = dimnames(raw_data_formatted))

  # Create a matrix of character strings as above, but paste together odds ratios 
  # and p-values so that each resulting cell has the format "OR (p-value)"
  table_data2 = matrix(paste("\n", odds_data_formatted, " (", p_data_formatted, ")", sep = ""),
                       nrow = nrow(odds_data_formatted), ncol = ncol(odds_data_formatted), 
                       dimnames = dimnames(odds_data_formatted))
  
  
  # Heatmap colors each cell proportionately to its value.  Taking sqrt(log2(1/p-value))
  # scales the values so they are closer together and lower p-values are coded as higher values
  # We want the heatmap to color the low p-values with the brightest colors
  hm_matrix = sqrt(log2(1/p_data))
  row.names(hm_matrix) = names(beer_data)
  colnames(hm_matrix) = names(store_data)

  # Returns length of longest string in row and column names
  row_max_length = longest.string(row.names(hm_matrix))
  col_max_length = longest.string(colnames(hm_matrix))
  
  # Open a png file for drawing the plot.  
  png(output_file, width = length(store_data)*1000, height = length(store_data)*1000, res = length(store_data)*60)
  par(font = 2, font.lab = 2, font.axis = 2, cex.main = 2)
  heatmap.3(hm_matrix, 
            cellnote = table_data1, 
            notecol = "black",
            cellnote2 = table_data2,
            notecex2 = 3.5,
            col = colorpanel(1000, "darkgray","yellow2"),
            trace = "none", 
            margins = c(1,1), 
            Rowv = F, Colv = F,
            dendrogram = "none", key = F, density.info = "none",
            add.expr = abline(h = 1:(nrow(x)+1)-0.5, v = 1:(ncol(x)+1)-0.5, lwd = 2),
            main = NULL, xlab = NULL, ylab = NULL, 
            cexRow = length(store_data)*1.5, 
            cexCol = length(store_data)*1.5,
            notecex = length(store_data)*2,
            lmat=rbind(c(5,0,4),c(3,1,2),c(0,0,0)),
            lhei=c(0.1, length(store_data)*1.5, col_max_length*0.2),
            lwid=c(0.1, length(store_data)*1.5, row_max_length*0.2)      
  )
  invisible(dev.off())
}

my_function()


