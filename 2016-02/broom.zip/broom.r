
#    =======================================
#    === Making By-Group Analyses Easier === 
#    ===    Using the broom Package      ===
#    ===         Bob Muenchen            ===
#    ===    muenchen.bob@gmail.com       ===
#    =======================================

#---LOAD PRACTICE DATA---
#
setwd("~/R4DATA") 
load("mytable.RData")
library("dplyr")
mytable

#---INSTALL PACKAGES---
#
# install.packages("broom") # by David Robinson
# install.packages("dplyr") # by Hadley Wickham


#---BGA1: R'S BUILT-IN APPROACH---
#         TO BY-GROUP ANALYSIS
#
# 1. Create a function that does the 
#    analysis you need
#
# 2. Apply the function using by() or
#    tapply() 
#
# 3. Save output to a list
#
# 4. Study the structure of that list 
#    using str()
#
# 5. Write an extractor function to pull
#    out values you need
#
# 6. Apply that function using lapply()
#
# 7. For each type of model, 
#    you start from scratch!
#
# We'll use dplyr + broom instead.
# That's MUCH easier!


#---BGA2: RECALL HOW t.test WORKS---
#
# Recall how t.test works
#
with(mytable, 
     t.test(posttest ~ gender))


#---BGA3: broom PACKAGE CLEANS IT UP---
#
# Converts output to a dataframe
#
# Standardizes "variable" names
#
library("broom")
glance(
  with(mytable, 
     t.test(posttest ~ gender)))


#---BGA4: PREPARE FOR BY-GROUP ANALYSIS---
#
# Recall that group_by prepares data set
# for grouped analysis by other dplyr 
# functions
#
library("dplyr")
by_workshop <- 
  group_by(mytable, workshop)


#---BGA5: SIMPLE ANALYSIS BY GROUP---
#
do(by_workshop, 
   glance( with(.,
     t.test(posttest ~ gender))))


#---BGA6: dplyr's do() FUNCTION---
#
# mutate() & summarise() can apply simple
# functions that return single values
#
# do() can apply any function by group,
# even complex ones that return lists
#
# It uses "." to refer to the current
# group's data frame


#---BGA7: broom PACKAGE'S FUNCTIONS---
#
# glance() 
# - Saves model-level info
# - Simple analyses:  saves all (t.test, cor.test)
# - Complex analyses: saves R-squared, AIC, etc.
# - Results always fit in one row
#
# tidy() 
# - Saves coefficient-level info like
#   regression coefficients, p-values, etc.
# - Results in one row per coefficient, cluster...
#
# augment() 
# - Saves observation-level info like
#   ".fitted", ".resid", ".cooksd",...
# - Results in one row per observation


#---BGA8: MODEL-LEVEL REGRESSION---
#
# glance() gets model summary measures
#
do(by_workshop, 
   glance( 
     with(.,
       lm(posttest ~ pretest))))

#---BGA9: COEFFICIENT-LEVEL REGRESSION---
#
# tidy() gets coefficient level measures
#
do(by_workshop, 
   tidy( 
     with(.,
       lm(posttest ~ pretest))))


#---BGA10: OBSERVATION-LEVEL REGRESSION---
#
# augment() adds fitted values, etc.
#
do(by_workshop, 
   augment( 
     with(.,
       lm(posttest ~ pretest))))


#---BGA11: ADVANCED FEATURES---
#
# What can broom handle? A lot!
methods(tidy)
#
# However, broom functions don't save everything
#
# do() can get *everything* out of a model,
# but without broom functions, it's up to you 
# to dig through each model's complex 
# "list of lists" output
#
# See help(do) for examples of its
# full power


#---QUESTIONS?---
